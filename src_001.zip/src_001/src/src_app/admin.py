from django.contrib import admin
from src_app.models import *
from src_app.models import *

# Register your models here.

class Questionasetadmin(admin.ModelAdmin):
    list_display = ['set_name','set_slug','enable_negative_marking','negative_mrking_percentage','time']

class questionAdmin(admin.ModelAdmin):
    list_display = [' id','question_text','question_image','question_type','question_order','question_marks']

class questionoptionsAdmin(admin.ModelAdmin):
    list_display = ['id','option_text','option_image','option_order','correct_answer','marks']

class groupinlinequestionsAdmin(admin.ModelAdmin):

    list_display = ['id_group_question','id_question','question_order','question_marks']





admin.site.register(Questionaset,Questionasetadmin)
admin.site.register(question,questionAdmin)
admin.site.register(questionoptions,questionoptionsAdmin)
admin.site.register(groupinlinequestions,groupinlinequestionsAdmin)
