from django.shortcuts import render
from django.shortcuts import render
from django.core.paginator import Paginator, PageNotAnInteger,EmptyPage
from src_app.models import *

def index(request):
    return render(request,'src_temp/index1.html')

def Questionaset_View(request):
    Questionaset_list=Questionaset.objects.all()
    paginator=Paginator(Questionaset_list)
    page_number=request.GET.get('page')
    try:
        Questionaset_list=paginator.page(page_number)
    except PageNotAnInteger:
        Questionaset=paginator.page(1)
    except EmptyPage:
        Questionaset=paginator.page(paginator.num_pages)
    return render(request,'src_temp/Memorial_info.html',{'memorial_info_list':Questionaset_list})

def question_View(request):
    question_list = question.objects.all()
    paginator = Paginator(question_list)
    page_number = request.GET.get('page')
    try:
        question_list = paginator.page(page_number)
    except PageNotAnInteger:
        question_list = paginator.page(1)
    except EmptyPage:
        question_list = paginator.page(paginator.num_pages)
    return render(request, 'src_temp/Memorial_competitons.html', {'question_list': question_list})

def questionoptions_View(request):
    questionoptions_list = questionoptions.objects.all()
    paginator = Paginator(questionoptions_list)
    page_number = request.GET.get('page')
    try:
        questionoptions_list = paginator.page(page_number)
    except PageNotAnInteger:
        questionoptions_list = paginator.page(1)
    except EmptyPage:
        questionoptions_list = paginator.page(paginator.num_pages)
    return render(request, 'src_temp/International.html', {'questionoptions_list': questionoptions_list})

def groupinlinequestions_View(request):
    groupinlinequestions_list = groupinlinequestions.objects.all()
    paginator = Paginator(groupinlinequestions_list)
    page_number = request.GET.get('page')
    try:
        groupinlinequestions_list = paginator.page(page_number)
    except PageNotAnInteger:
        groupinlinequestions_list = paginator.page(1)
    except EmptyPage:
        groupinlinequestions_list = paginator.page(paginator.num_pages)
    return render(request, 'src_temp/Memorial_vigits_and_online_events.html', {'groupinlinequestions_list': groupinlinequestions_list})


