from django.db import models


# Create your models here.

class Questionaset(models.Model):
    set_name= models.CharField(max_length=50)
    set_slug = models.CharField(max_length=20)
    enable_negative_marking = models.CharField(max_length=200)
    negative_mrking_percentage = models.CharField(max_length=20)
    time = models.DateField()

class question(models.Model):
    id = models.CharField(max_length=20)
    question_text = models.CharField(max_length=20)
    question_image = models.URLField()
    question_type = models.DateField()
    question_order = models.CharField(max_length=200)
    question_marks = models.CharField(max_length=200)


class questionoptions(models.Model):
    id = models.CharField(max_length=40)
    option_text = models.CharField(max_length=10)
    option_image = models.CharField(max_length=20)
    option_order = models.CharField(max_length=50)
    correct_answer = models.CharField(max_length=20)
    marks = models.CharField(max_length=20)



class groupinlinequestions(models.Model):
    id_group_question = models.CharField(max_length=20)
    id_question = models.CharField(max_length=200)
    question_order = models.CharField(max_length=20)
    question_marks = models.IntegerField()



