from django.conf.urls import url,include
from rest_framework import routers
from src_app.api.views import Memorial_info_CRUDCBV,Memorial_competitons_CRUDCBV,International_CRUDCBV,Memorial_vigits_and_online_events_CRUDCBV,Archives_CRUDCBV,Documentaries_CRUDCBV,COVID_Groups_CRUDCBV,Articles_and_op_eds_about_covid_CRUDCBV,MTM_mail_merge_CRUDCBV
router=routers.DefaultRouter()
router.register('Memorial_info',Memorial_info_CRUDCBV)
router.register('Memorial_competitons_info',Memorial_competitons_CRUDCBV)
router.register('International_info',International_CRUDCBV)
router.register('Memorial_vigits_and_online_events_info',Memorial_vigits_and_online_events_CRUDCBV)
router.register('Archives_info',Archives_CRUDCBV)
router.register('Documentaries_info',Documentaries_CRUDCBV)
router.register('COVID_Groups_info',COVID_Groups_CRUDCBV)
router.register('Articles_and_op_eds_about_covid_CRUDCBV_info',Articles_and_op_eds_about_covid_CRUDCBV)
router.register('MTM_mail_merge_info',MTM_mail_merge_CRUDCBV)

urlpatterns = [
url(r'', include(router.urls)),
]