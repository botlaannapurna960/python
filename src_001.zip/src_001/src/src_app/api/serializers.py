from rest_framework.serializers import ModelSerializer
#pip install djangorestframeworkfrom rest_framework import serializerspip
from src_app.models import Memorial_info,Memorial_competitons,International,Memorial_vigits_and_online_events,Archives,Documentaries,COVID_Groups,Articles_and_op_eds_about_covid,MTM_mail_merge
class Questionaset_ser(ModelSerializer):
    class Meta:
        model=Questionaset
        fields='__all__'
class question_ser(ModelSerializer):
    class Meta:
        model=question
        fields='__all__'
class questionoptions_ser(ModelSerializer):
    class Meta:
        model=questionoptions
        fields='__all__'
class groupinlinequestions_ser(ModelSerializer):
    class Meta:
        model=groupinlinequestions
        fields='__all__'
