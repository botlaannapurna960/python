from rest_framework import viewsets
from src_app.models import Memorial_info,Memorial_competitons,International,Memorial_vigits_and_online_events,Archives,Documentaries,COVID_Groups,Articles_and_op_eds_about_covid,MTM_mail_merge
from src_app.api.serializers import Memorial_info_ser,Memorial_competitons_ser,International_ser,Memorial_vigits_and_online_events_ser,Archives_ser,Documentaries_ser,COVID_Groups_ser,Articles_and_op_eds_about_covid_ser,MTM_mail_merge_ser
class Questionaset_CRUDCBV(viewsets.ModelViewSet):
    serializer_class=Questionaset_ser
    queryset=Questionaset.objects.all()
class question_CRUDCBV(viewsets.ModelViewSet):
    serializer_class=question_ser
    queryset=question.objects.all()
class questionoptions_CRUDCBV(viewsets.ModelViewSet):
    serializer_class=questionoptions_ser
    queryset=questionoptions.objects.all()
class groupinlinequestions_CRUDCBV(viewsets.ModelViewSet):
    serializer_class=groupinlinequestions_ser
    queryset=groupinlinequestions.objects.all()

