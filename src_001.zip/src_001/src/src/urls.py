"""src URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url,include
from django.contrib import admin
from src_app import views
urlpatterns = [
url(r'^admin/', admin.site.urls),
url(r'^$', views.index),
url(r'^Memorial_info/', views.Memorial_info_View),
url(r'^Memorial_competitons/', views.Memorial_competitons_View),
url(r'^International/', views.International_View),
url(r'^Memorial_vigits_and_online_events/', views.Memorial_vigits_and_online_events_View),
url(r'^Archives_View/', views.Archives_View),
url(r'^COVID_Groups/', views.COVID_Groups_View),
url(r'^Articles_and_op_eds_about_covid/', views.Articles_and_op_eds_about_covid_View),
url(r'^MTM_mail_merge/', views.MTM_mail_merge_View),

url(r'^api/', include('src_app.api.urls')),
]

